var suffixURL = "";
//var suffixURL = "/ersandeeppruthi";
weekday = new Array(7);
weekday[0] = "Monday";
weekday[1] = "Tuesday";
weekday[2] = "Wednesday";
weekday[3] = "Thursday";
weekday[4] = "Friday";
weekday[5] = "Saturday";
weekday[6] = "Sunday";
defaultWeek = "";
defaultDate = "";
selectedType = "";
selectedOption = "";
weekArray = [];
weekDatesArray = [];
fullweekData = [];
isOptionControlExists = false;

$(document).ready(function () {
    loadQuityMasterData();
});

function openDatesTab() {
    gridData = null;
    gridData = [];
    var totalDayLoad = 0;
    var totalDayLoaded = 0;

    $('#chartContainer1').html("");
    $('#chartContainer2').html("");
    $('#chartContainer3').html("");
    $('#chartContainer4').html("");
    $('#chartContainer5').html("");
    $('#chartContainer6').html("");

    $('.tab').html("");
    var count = 1;
    var selectedWeek = $('#WeekDropdown').find(":selected").text();
    $('#DateDropdown').empty()
    weekDatesArray = weekArray.filter(function (index) { return index.WeekString == selectedWeek })[0].Dates;

    if (isOptionControlExists == true) {
        $('#OptionNameDropdown').empty();
        var selectedTypeFirst = $('#TypeDropdown').find(":selected").text();
        $.ajax({
            type: "GET",
            crossDomain: true,
            url: suffixURL + "/Data/GetSName?name=" + selectedType + "&type=" + selectedTypeFirst + "&date=" + weekDatesArray[0],
            async: false,
            contentType: "application/json",
            success: function (response) {
                $.each(response, function (index, value) {
                    var valueFound = false;
                    for (var i = 0; i < value.length; i++) {
                        var name = value[i];
                        for (var k = 0; k < weekDatesArray.length; k++) {
                            if (name.indexOf(weekDatesArray[k]) != -1) {
                                $('#OptionNameDropdown').append($('<option>').text(index).attr('value', index));
                                valueFound = true;
                                break;
                            }
                        }
                        if (valueFound)
                            break;
                    }
                });
            }
        });
    }
    $.each(weekDatesArray, function (index1, value1) {
        var date2 = new Date(value1);
        $('.tab').append("<button class='tablinks' id='" + value1 + "' onclick=showDates('" + value1 + "')>" + value1 + "(" + weekday[date2.getDay() - 1] + ")" + "</button>");
        $('#DateDropdown').append($('<option>').text("Day" + count + "-" + value1).attr('value', value1));
    });

    loadDatesData();
}

function loadDatesData() {
    selectedOption = $('#OptionNameDropdown').find(":selected").val()
    $.each(weekDatesArray, function (index1, value1) {
        if (!isOptionControlExists)
            loadDateDataFromServer(value1, selectedType);
        else
            loadDateDataFromServer(value1, selectedOption);
    });

    if (defaultDate != "") {
        setTimeout(function () { showDateData(defaultDate); defaultDate = ""; }, 1000);
    }
    else
        setTimeout(function () { showDates(weekDatesArray[0]); }, 1000);
}


function loadDateDataFromServer(date, typeSlected) {
    var selectedTypeFirst = $('#sType').find(":selected").text();
    $.ajax({
        type: "GET",
        crossDomain: true,
        url: suffixURL + "/Data/GetData?Date=" + date + "&name=" + typeSlected + "&type=" + selectedTypeFirst,
        async: true,
        contentType: "application/json",
        success: function (response) {
            gridData[date] = response;
            //totalDayLoaded = totalDayLoaded + 1;
            //$('title').text("Total- " + totalDayLoad + "-Loaded-" + totalDayLoaded);
        },
    });
}

function showDateData(defaultDate) {
    $('.tablinks').removeClass("selected");
    $('#DateDropdown').val(defaultDate);
    $('#' + defaultDate).addClass("selected");
}

function loadQuityMasterData() {
    $.ajax({
        type: "GET",
        crossDomain: true,
        url: suffixURL + "/Nse/GetMasterEquity",
        async: true,
        contentType: "application/json",
        success: function (response) {
            weekArray = response;
            $.each(response, function (index, value) {
                $('#equityMaster').append($('<option>').text(value.Symbol + "|" + value.Identifier).attr('value', value.Symbol));
            });
            $('.equityMasterDiv').dropdown({
                input: '<input type="text" maxLength="20" placeholder="Search">'
            });

        },
    });
}

function loadData2(input2, id) {
    let dps = [];
    let dps2 = [];
    if (arrCanvas[id] != null) {
        arrCanvas[id].destroy();
        arrCanvas[id] = null;
    }
    $('#' + id).removeClass('displayNone');
    let chart = new CanvasJS.Chart(id, {
        zoomEnabled: true,
        exportEnabled: true,
        title: {
            text: "Chart"
        },
        axisX: {
            intervalType: "minute",
            valueFormatString: "hh:mm",
            scaleBreaks: {
                autoCalculate: true,
                lineThickness: 0,
                spacing: 0
            }
        },
        axisY: {
            title: "Price",
        },
        data: [{
            type: "candlestick",
            name: "Stock Price",
            risingColor: "green",
            color: "red",
            showInLegend: true,
            yValueFormatString: "##0.00",
            xValueFormatString: "DD HH:mm",
            xValueType: "dateTime",
            dataPoints: dps
        },
        {
            type: "line",
            showInLegend: true,
            risingColor: "green",
            name: "Total Revenue",
            axisYType: "secondary",
            yValueFormatString: "$#,##0.00bn",
            xValueFormatString: "MMMM",
            dataPoints: dps2
        }]
    });

    let totalAmount = 0;
    for (var i = 0; i < input2.length; i++) {
        dps.push({
            x: input2[i].x,
            y: input2[i].y
        });
        totalAmount = totalAmount + input2[i].z;
        dps2.push({
            x: input2[i].x,
            y: totalAmount
        });
    }
    addCustomBreak(chart);
    chart.render();
    arrCanvas[id] = chart;
}

function addCustomBreak(chart) {
    var diffBetweenDps, startValue, endValue, noOfDays;
    var customBreaks = [];
    noOfDays = 60000;
    for (var i = 1; i < chart.options.data[0].dataPoints.length; i++) {
        diffBetweenDps = new Date(chart.options.data[0].dataPoints[i].x) - new Date(chart.options.data[0].dataPoints[i - 1].x);
        if (diffBetweenDps > noOfDays) {
            var startDate = chart.options.data[0].dataPoints[i - 1].x;
            var endDate = chart.options.data[0].dataPoints[i].x;
            startValue = new Date(startDate.setMinutes(startDate.getMinutes() + 1))
            endValue = new Date(endDate.setMinutes(endDate.getMinutes() - 1))
            customBreaks.push({
                startValue: startValue,
                endValue: endValue
            })
        }
    }
    //if (!chart.options.axisX)
    //    chart.options.axisX = {};
    //if (!chart.options.axisX.scaleBreaks)
    //    chart.options.axisX.scaleBreaks = { type: "straight", lineThickness: 0, spacing: 0 };

    chart.options.axisX.scaleBreaks.customBreaks = customBreaks;
}
var arrCanvas = [];
function loadData(input2, id) {
    let dps = [];
    let dps2 = [];
    if (arrCanvas[id] != null) {
        arrCanvas[id].destroy();
        arrCanvas[id] = null;
    }

    $('#' + id).removeClass('displayNone');
    let chart = new CanvasJS.Chart(id, {
        zoomEnabled: true,
        exportEnabled: true,
        title: {
            text: "Chart"
        },
        axisX: {
            intervalType: "minute",
            valueFormatString: "hh:mm"
        },
        axisY: {
            title: "Price",
        },
        data: [{
            type: "candlestick",
            name: "Stock Price",
            risingColor: "green",
            color: "red",
            showInLegend: true,
            yValueFormatString: "##0.00",
            xValueFormatString: "HH:mm",
            xValueType: "dateTime",
            dataPoints: dps
        },
        {
            type: "line",
            showInLegend: true,
            risingColor: "green",
            name: "Total Revenue",
            axisYType: "secondary",
            yValueFormatString: "$#,##0.00bn",
            xValueFormatString: "MMMM",
            dataPoints: dps2
        }]
    });

    let totalAmount = 0;
    for (let i = 0; i < input2.length; i++) {
        dps.push({
            x: input2[i].x,
            y: input2[i].y
        });
        //totalAmount = totalAmount + input2[i].z;
        totalAmount = input2[i].z / 50;
        dps2.push({
            x: input2[i].x,
            y: totalAmount
        });
    }

    chart.render();
    arrCanvas[id] = chart;
    dps = null;
    dps2 = null;
    //chart.destroy();
    //chart = null;
}

function getParameterByName(name, url = window.location.href) {
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return "";
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}



function showDates(date) {
    $('.tablinks').removeClass("selected");
    $('#DateDropdown').val(date);
    $('#' + date).addClass("selected");
    $('#records_table').html("");
    $('#TimeDropdown').html("");
    $('.chart').addClass('displayNone');
    var arrayItem = gridData[date];
    $.each(arrayItem, function (i, item) {
        if (i != 0) {
            $('#TimeDropdown').append($('<option>').text(item.time.replace(date + "T", "")).attr('value', item.time));
        }
    });
    openTimesTab(date);
    var selectedIndex2 = $("#DateDropdown").prop('selectedIndex');
    if (selectedIndex2 == 1) {
        showChart($("#DateDropdown option:eq(0)").val(), "chartContainer2")
    }
    else if (selectedIndex2 == 2) {
        showChart($("#DateDropdown option:eq(0)").val(), "chartContainer3")
        showChart($("#DateDropdown option:eq(1)").val(), "chartContainer2")
    }
    else if (selectedIndex2 == 3) {
        showChart($("#DateDropdown option:eq(0)").val(), "chartContainer4")
        showChart($("#DateDropdown option:eq(1)").val(), "chartContainer3")
        showChart($("#DateDropdown option:eq(2)").val(), "chartContainer2")
    }
    else if (selectedIndex2 == 4) {
        showChart($("#DateDropdown option:eq(0)").val(), "chartContainer5")
        showChart($("#DateDropdown option:eq(1)").val(), "chartContainer4")
        showChart($("#DateDropdown option:eq(2)").val(), "chartContainer3")
        showChart($("#DateDropdown option:eq(3)").val(), "chartContainer2")
    }

}

function showPendingDataChart() {
    fullweekData = [];
    var selectedTime = $('#TimeDropdown').find(":selected").val();
    adddataInArray(gridData[$("#DateDropdown option:eq(0)").val()], selectedTime);
    adddataInArray(gridData[$("#DateDropdown option:eq(1)").val()], selectedTime);
    adddataInArray(gridData[$("#DateDropdown option:eq(2)").val()], selectedTime);
    adddataInArray(gridData[$("#DateDropdown option:eq(3)").val()], selectedTime);
    adddataInArray(gridData[$("#DateDropdown option:eq(4)").val()], selectedTime);
    showPendingData();
}

function adddataInArray(arrayData, selectedTime) {
    $.each(arrayData, function (i, item) {
        if (item.time < selectedTime) {
            fullweekData.push(item);
        }
        else {
            return;
        }
    });
}

function showPendingData() {
    var dps = [];
    fullweekData.pop();
    var maxAmount = $("#txtMaxAmount").val();
    $.each(fullweekData, function (i, item) {
        var arrayO = [];
        arrayO[0] = item.openprice;
        arrayO[1] = item.highprice;
        arrayO[2] = item.lowprice;
        arrayO[3] = item.closePrice;
        var highTenPercentagebreak = false;
        var target = item.highprice + (item.highprice / 10.0);
        var maxValue = 0;
        for (var k = i + 1; k < fullweekData.length; k++) {
            if (fullweekData[k].highprice > target) {
                highTenPercentagebreak = true;
                break;
            }
            if (maxValue < fullweekData[k].highprice) {
                maxValue = fullweekData[k].highprice;
            }
        }
        if (highTenPercentagebreak == false) {
            //debugger;
            maxValue = maxValue - item.highprice / 10.0;

            var OiDifference = 0;
            try {
                OiDifference = item.TotalOI - fullweekData[i - 1].TotalOI;
                if (OiDifference < 0)
                    OiDifference = 0;
            }
            catch {

            }
            if (maxAmount == 0 || maxAmount > item.lowprice) {
                //debugger;
                if (item.lowprice < maxValue)
                    item.lowprice = maxValue;
                if (item.openprice < maxValue)
                    item.openprice = maxValue;

                dps.push({
                    x: new Date(item.time),
                    y: arrayO,
                    z: OiDifference
                });
            }
        }
    });
    if ($('#chartContainer6').length > 0)
        loadData2(dps, "chartContainer6");
}
function showChart(date, id) {
    var dps = [];
    $.each(gridData[date], function (i, item) {
        var arrayO = [];
        arrayO[0] = item.openprice;
        arrayO[1] = item.highprice;
        arrayO[2] = item.lowprice;
        arrayO[3] = item.closePrice;
        var OiDifference = 0;
        try {
            OiDifference = item.TotalOI;
            //OiDifference = item.TotalOI - fullweekData[i - 1].TotalOI;
            //if (OiDifference < 0)
            //    OiDifference = 0;
        }
        catch
        {

        }
        dps.push({
            x: new Date(item.time),
            y: arrayO,
            z: OiDifference
        });
    });

    loadData(dps, id);
}

function openTimesTab(date) {
    var dps = [];
    var dps2 = [];

    $('#records_table').html("");
    var dateSelected = $('#DateDropdown').find(":selected").val();
    var selected = $('#TimeDropdown').find(":selected").val();
    dps = []
    var trHTML = '';
    var totalAmount = 0;
    $.each(gridData[dateSelected], function (i, item) {
        if (item.time < selected) {
            var arrayO = [];
            arrayO[0] = item.openprice;
            arrayO[1] = item.highprice;
            arrayO[2] = item.lowprice;
            arrayO[3] = item.closePrice;
            //debugger;
            dps.push({
                x: new Date(item.time),
                y: arrayO,
                z: item.TotalOI
            });
        }
    });

    $('#records_table').append(trHTML);

    loadData(dps, "chartContainer1");
    if (isMainPage() == true)
        showPendingDataChart();
}
function isMainPage() {
    let url = window.location.href.indexOf("/Dates.html");
    if (url != -1)
        return false;
    return true;
}


function getEquityResult() {
    var data = $('#equityMaster').val();;
    $.support.cors = true;
    var reqObject = {};
    reqObject.equitySymbol = data;
    var reqObjecttoSendt = JSON.stringify(reqObject);

    $.ajax({
        type: "POST",
        crossDomain: true,
        url: suffixURL + "/NSE/GetResult",
        data: reqObjecttoSendt,
        async: true,
        contentType: "application/json",
        dataType: 'json',
        success: function (data) {

            var headers = Object.keys(data[0]);

            //Prepare html header
            var headerRowHTML = '<tr>';
            $.each(headers, function (i, header) {
                headerRowHTML += '<th>' + header + '</th>';
            });
            headerRowHTML += '</tr>';

            //Creating table with headers
            var tableHTML = '<table cellpadding="0" cellspacing="0"  border="1px solid black">';

            //Prepare all the employee records as HTML
            var allRecordsHTML = '';
            $.each(data, function (i, row) {

                //Prepare html row
                allRecordsHTML += '<tr style="border:1px solid black;">';
                $.each(headers, function (j, header) {
                    allRecordsHTML += '<td>' + row[header] + '</td>';
                });
                allRecordsHTML += '</tr>';

            });
            tableHTML = tableHTML + headerRowHTML + allRecordsHTML + '</table>';
            //Appending the all records to table
            $("#divTable").html(tableHTML);

        },
    });

}