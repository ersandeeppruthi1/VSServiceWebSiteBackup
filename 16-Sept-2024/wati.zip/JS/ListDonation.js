﻿$(document).ready(function () {
    var table = null; // Variable to store DataTable instance

    // Hide the no records message initially
    $("#noRecordsMessage").hide();

    // Set the default "Start Date" to the first day of the current month
    var currentDate = new Date();
    var firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    var formattedStartDate = firstDayOfMonth.toISOString().substring(0, 10);
    $("#startDate").val(formattedStartDate);

    // Set the default "End Date" to the last day of the current month
    var lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    var formattedEndDate = lastDayOfMonth.toISOString().substring(0, 10);
    $("#endDate").val(formattedEndDate);

    // Initialize DataTables with paging disabled and sorting enabled
    table = $('#dummyData').DataTable({
        "paging": false,
        "footerCallback": function (row, data, start, end, display) {
            var api = this.api();

            // Calculate the total amount
            var totalAmount = api
                .column(3, { search: 'applied' }) // Column index of "Amount"
                .data()
                .reduce(function (acc, val) {
                    var amount = parseFloat(val.replace('$', '').replace(',', ''));
                    return acc + amount;
                }, 0);

            // Update the "Total" cell in the footer row
            $(api.column(3).footer()).html(totalAmount.toFixed(2));
        }
    });

    // Function to update the total amount in the footer
    function updateTotalAmount() {
        var totalAmount = table
            .column(3, { search: 'applied' }) // Column index of "Amount"
            .data()
            .reduce(function (acc, val) {
                var amount = parseFloat(val.replace('$', '').replace(',', ''));
                return acc + amount;
            }, 0);

        $("#totalAmount").text(totalAmount.toFixed(2));
        table.draw(); // Redraw the table to update the footer
    }

    // Call updateTotalAmount when the page loads
    updateTotalAmount();

    // Handle click events on name links to show row data in a modal
    $("#dummyData tbody").on("click", ".name-link", function () {
        var rowData = $(this).closest("tr").find("td").map(function (index) {
            var columnHeader = $("#dummyData th").eq(index).text();
            var cellData = $(this).text();
            return {
                columnHeader: columnHeader,
                cellData: cellData
            };
        }).get();

        // Populate the detail view with data from the selected row
        $("#detailName").text(rowData[0].cellData); // Update this line with other detail view elements

        // Toggle to the detail view initially
        toggleDetailView();

        // Show the modal
        $("#rowDataModal").modal("show");
    });

    // Handle click events on the "Edit" button in the modal
    $("#editButton").click(function () {
        // Toggle to the edit form view
        toggleDetailView(true);
    });

    // Handle click events on the "Save" button in the modal
    $("#saveButton").click(function () {
        // Implement your logic to save the edited data here
        // Retrieve the edited data from the form fields and send it to the server
        submitAllRowsData();

        updateGridFromForm();


        // After saving, toggle back to the detail view
        toggleDetailView(false);
    });

    // Function to collect and submit all rows data
    function submitAllRowsData() {
        var rowDataArray = JSON.stringify({
            SlipDate: $("[id = 'editSlip Date']").val(),
            Address: $('#editAddress').val(),
            SerialNumber: $("[id = 'editSerial Number']").val(),
            MobileNumber: $('#editMobile').val(),
            EmailAddress: $('#editEmail').val(),
            Amount: parseInt($('#editAmount').val()),
            Name: $('#editName').val(),
            PanCard: $('#editPanCard').val(),
            id: $('#editID').val()
        });

        // Send the collected data to the server using an AJAX request
        $.ajax({
            url: '/RajorPay/UpdateData', // Replace with your server endpoint URL
            method: 'POST',
            contentType: 'application/json',
            data: rowDataArray,
            success: function (response) {
                // Handle success response from the server
                console.log('Data submitted successfully:', response);
            },
            error: function (error) {
                // Handle error response from the server
                console.error('Error submitting data:', error);
            }
        });
    }


    function updateGridFromForm() {
        // Update the detail view
        var detailViewContent = '';
        var cellIndex = 0;
        var editId = $('#editID').val();
        // Loop through all rows in the edit form
        $('#editForm div').each(function () {
            var row = $(this);
            var label = row.find('label').text(); // Get the label text
            var value = row.find('input').val(); // Get the input value
            if (label == "Address")
                detailViewContent += "<strong>" + label + ":</strong> " + $('#editAddress').val() + "<br>";
            else
                detailViewContent += "<strong>" + label + ":</strong> " + value + "<br>";



            // Update the corresponding cell in the grid
            $('#dummyData tbody tr').each(function () {
                var gridRow = $(this);

                var cell = gridRow.find('td').eq(9);

                // Update the cell content in the grid
                if (cell.text() == editId) {
                    var cell = gridRow.find('td').eq(cellIndex);

                    // Update the cell content in the grid
                    if (label == "Name")
                        cell.html('<a href="#" class="name-link">' + value + '</a>');
                    else if (label == "Slip Date")
                        cell.html('<a href="/RajorPay/GeneratePdf?id=' + editId + '" class="date-link" data-id="' + editId + '">' + value + '</a>');
                    else
                        cell.text(value);
                }
            });

            cellIndex++;
        });

        // Update the detail view content
        $("#detailView").html(detailViewContent);
    }
    // Handle click events on the "Close" button in the modal header
    $("#closeButton").click(function () {
        // Toggle back to the detail view
        toggleDetailView(false);
    });

    // Function to toggle between detail view and edit form view
    function toggleDetailView(editMode) {
        if (editMode) {
            $("#detailView").hide(); // Hide detail view
            $("#editForm").show(); // Show edit form
            $("#editButton").hide(); // Hide the "Edit" button
            $("#saveButton").show(); // Show the "Save" button
            $("#downloadPdfButton").hide(); // Show the "Save" button
            $("#sendReceiptButton").hide(); // Show the "Save" button
            $("#rowDataModalLabel").text("Edit Payment"); // Change modal title
        } else {
            $("#detailView").show(); // Show detail view
            $("#editForm").hide(); // Hide edit form
            $("#editButton").show(); // Show the "Edit" button
            $("#saveButton").hide(); // Hide the "Save" button
            $("#downloadPdfButton").show(); // Show the "Save" button
            $("#sendReceiptButton").show(); // Show the "Save" button
            $("#rowDataModalLabel").text("Payment Detail"); // Change modal title
        }
    }


    // Function to fetch data from the API
    function fetchData() {
        // Get the current URL
        var currentUrl = window.location.href;

        // Define the API endpoint without the prefix
        var apiUrl = '/RajorPay/GetListData';

        // Check if the current URL contains the prefix
        if (currentUrl.includes('ersandeeppruthi')) {
            // Add the prefix to the API endpoint
            apiUrl = '/ersandeeppruthi' + apiUrl;
        }

        $("#overlay").show();

        // Make an AJAX request to the API (replace with your actual API endpoint)
        $.ajax({
            url: apiUrl,
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                startDate: $("#startDate").val(),
                endDate: $("#endDate").val()
            }),
            success: function (data) {
                // Call createTable to update the table with the API response data
                createTable(data);
                $("#overlay").hide();
            },
            error: function (error) {
                // Handle any errors from the API request
                console.error('Error:', error);
                alert('An error occurred while fetching data from the API.');
                $("#overlay").hide();
            }
        });
    }


    // Fetch data from the API on page load
    fetchData();

    // Handle click event on the "Search" button
    $("#searchButton").click(function () {
        // Fetch data from the API when the "Search" button is clicked
        fetchData();
    });

    // Function to create the table based on the JSON data
    function createTable(data) {
        //var table = $('#dummyData').DataTable();
        if (table) {
            // If DataTable is already initialized, destroy it before reinitializing
            table.destroy();
        }

        table = $('#dummyData').DataTable({
            "paging": false,
            "order": [[10, "desc"]], // Sort by column index 2 (Slip Date) in descending order
            "columnDefs": [
                {
                    targets: 0, // The column index of "Name"
                    render: function (data, type, row) {
                        // Create a hyperlink with the name
                        return '<a href="#" class="name-link">' + data + '</a>';
                    }
                },
                {
                    "targets": 2, // Index of the "Slip Date" column (zero-based)
                    "render": function (data, type, row) {
                        // Format the date as "dd-MMM-yyyy"
                        var date = new Date(data);
                        var day = date.getDate();
                        var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                        var monthIndex = date.getMonth();
                        var year = date.getFullYear();
                        var dateName = day + "-" + monthNames[monthIndex] + "-" + year;
                        return '<a href="/RajorPay/GeneratePdf?id=' + row[9] + '" class="date-link" data-id="' + row[9] + '">' + dateName + '</a>';
                    }
                }
            ],
            "footerCallback": function (row, data, start, end, display) {
                var api = this.api();

                // Calculate the total amount
                var totalAmount = api
                    .column(3, { search: 'applied' }) // Column index of "Amount"
                    .data()
                    .reduce(function (acc, val) {
                        var amount = parseFloat(val.replace('$', '').replace(',', ''));
                        return acc + amount;
                    }, 0);
                var formattedTotalAmount = totalAmount.toLocaleString('en-IN', {
                    style: 'currency',
                    currency: 'INR'
                }).replace('₹', ''); // Remove the rupee symbol;

                // Update the "Total" cell in the footer row
                $(api.column(3).footer()).html(formattedTotalAmount);
            }
        });

        // Clear existing table data
        table.clear().draw();

        // Loop through the JSON data and add rows to the table
        for (var i = 0; i < data.length; i++) {
            var rowData = data[i];

            // Format the "Amount" with toLocaleString and right-align it
            var formattedAmount = rowData.Amount.toLocaleString('en-IN', {
                style: 'currency',
                currency: 'INR'
            }).replace('₹', ''); // Remove the rupee symbol;

            // Add the row to the table
            var row = table.row.add([
                rowData.Name,
                rowData.MobileNumber,
                rowData.SlipDate,
                formattedAmount,
                rowData.EmailAddress,
                rowData.PanCard,
                rowData.Address,
                rowData.SerialNumber,
                rowData.PaymentId,
                rowData.id,
                rowData.Createdon
            ]).draw(false).node();

            // Add the CSS class to the EmailAddress column cell
            $(row).find('td:eq(0)').addClass('name-link');
            $(row).find('td:eq(3)').addClass('text-end');
            $(row).find('td:eq(4)').addClass('displaynone');
            $(row).find('td:eq(5)').addClass('displaynone');
            $(row).find('td:eq(6)').addClass('displaynone');
            $(row).find('td:eq(7)').addClass('displaynone');
            $(row).find('td:eq(8)').addClass('displaynone');
            $(row).find('td:eq(9)').addClass('displaynone');
            $(row).find('td:eq(10)').addClass('displaynone');

        }

        // Update the total amount in the footer
        updateTotalAmount();

        // Hide the "No records found" message if data is available
        $("#noRecordsMessage").hide();

        // Function to populate the edit form HTML with data
        function populateEditFormHtml(editRowData) {
            // Initialize the edit form HTML
            var editFormHtml = '';

            // Loop through the row data for each column
            for (var i = 0; i < editRowData.length; i++) {
                var columnHeader = editRowData[i].columnHeader;
                var cellData = editRowData[i].cellData;

                // Generate the form input field based on the column data
                editFormHtml += '<div class="mb-3">';
                editFormHtml += '<label for="edit' + columnHeader + '" class="form-label">' + columnHeader + '</label>';

                // Check if the column header is "Address" and create a textarea input
                if (columnHeader === 'Address') {
                    editFormHtml += '<textarea class="form-control" id="edit' + columnHeader + '" name="edit' + columnHeader + '">' + cellData + '</textarea>';
                } else {
                    editFormHtml += '<input type="text" class="form-control" id="edit' + columnHeader + '" name="edit' + columnHeader + '" value="' + cellData + '"';

                    // Check if the column header is "Payment ID" or "ID" and add the disabled attribute
                    if (columnHeader === 'Payment ID' || columnHeader === 'ID' || columnHeader == "Createdon") {
                        editFormHtml += ' disabled';
                    }

                    editFormHtml += '>';
                }

                editFormHtml += '</div>';
            }

            // Set the inner HTML of the editForm to the generated HTML
            $("#editForm").html(editFormHtml);
        }


        // Function to update all rows in the grid from the form data



        // Handle click events on the "Name" links to show row data in a modal
        $("#dummyData tbody").on("click", ".name-link", function () {
            var rowData = $(this).closest("tr").find("td").map(function (index) {
                var columnHeader = $("#dummyData th").eq(index).text();
                var cellData = $(this).text();
                return "<strong>" + columnHeader + ":</strong> " + cellData;
            }).get();

            var editRowData = $(this).closest("tr").find("td").map(function (index) {
                var columnHeader = $("#dummyData th").eq(index).text();
                var cellData = $(this).text();
                return {
                    columnHeader: columnHeader,
                    cellData: cellData
                };
            }).get();

            var editRowData = $(this).closest("tr").find("td").map(function (index) {
                var columnHeader = $("#dummyData th").eq(index).text();
                var cellData = $(this).text();
                return {
                    columnHeader: columnHeader,
                    cellData: cellData
                };
            }).get();

            populateEditFormHtml(editRowData);


            var modalContent = rowData.join("<br>");

            // Set the content and title of the modal
            $("#detailView").html(modalContent);
            $("#rowDataModalLabel").text("Payment Detail");

            // Toggle to the detail view initially
            toggleDetailView(false);

            // Show the modal
            $("#rowDataModal").modal("show");
        });
    }

    // Export button click event handler
    $("#exportButton").click(function () {
        // Get the DataTable instance
        var dataTable = $('#dummyData').DataTable();

        // Get the filtered data from the DataTable
        var filteredData = dataTable.rows({ filter: 'applied' }).data();

        // Create a CSV string to store the filtered table data
        var csv = '';

        // Get the table headers
        var headers = [];
        $('#dummyData th').each(function () {
            headers.push('"' + $(this).text() + '"');
        });
        csv += headers.join(',') + '\n';

        // Iterate through the filtered data and add rows to the CSV
        filteredData.each(function (rowData) {
            var rowDataArray = [];
            rowDataArray.push('"' + rowData[0] + '"'); // Handle "Name" column separately
            for (var i = 1; i < rowData.length; i++) {
                rowDataArray.push('"' + rowData[i] + '"');
            }
            csv += rowDataArray.join(',') + '\n';
        });

        // Create a Blob (file) from the CSV data
        var blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });

        // Save the Blob as a file using FileSaver.js
        saveAs(blob, 'filtered_table_data.csv');
    });

    // Handle click events on the "Download PDF" button in the modal
    $("#downloadPdfButton").click(function () {
        // Get the ID of the payment record for which to generate the PDF
        var paymentId = $("#editID").val(); // Assuming you have an element with the ID "detailPaymentId" to store the payment ID

        // Construct the PDF download URL with the payment ID
        var pdfDownloadUrl = '/RajorPay/GeneratePdf?id=' + paymentId;

        // Trigger the PDF download by redirecting the user to the PDF download URL
        window.location.href = pdfDownloadUrl;
    });

    // Handle click events on the "Send Receipt" button in the modal
    $("#sendReceiptButton").click(function () {
        // Get the ID of the payment record for which to send the receipt
        var paymentId = $("#detailPaymentId").text(); // Assuming you have an element with the ID "detailPaymentId" to store the payment ID

        // Show the modal and full-page overlay
        $('#rowDataModal').modal('show');
        $("#overlay").show();

        // Make an AJAX request to the /RajorPay/SendEmail endpoint
        var paymentId = $("#editID").val(); // Assuming you have an element with the ID "detailPaymentId" to store the payment ID
        $.ajax({
            url: '/RajorPay/SendEmail?id=' + paymentId,
            method: 'Get',
            success: function () {
                // Close the modal and hide the overlay on success
                $('#rowDataModal').modal('hide');
                $("#overlay").hide();

                // Display the success alert message
                $("#successAlert").fadeIn(300).delay(3000).fadeOut(300); // Show for 3 seconds

                // Optionally, you can perform additional actions on success
            },
            error: function () {
                // Close the modal and hide the overlay on error
                $('#rowDataModal').modal('hide');
                $("#overlay").hide();

                // Display the error alert message
                $("#errorAlert").fadeIn(300).delay(3000).fadeOut(300); // Show for 3 seconds

                // Optionally, you can perform error handling
            }
        });
    });



});
