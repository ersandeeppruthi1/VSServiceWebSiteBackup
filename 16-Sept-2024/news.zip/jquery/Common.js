﻿function storeToken(token) {
    var expiryTime = new Date().getTime() + 24 * 60 * 1000;
    Cookies.set('token', token, { expires: new Date(expiryTime), path: '/' });
    Cookies.set('token_expiry', expiryTime, { expires: new Date(expiryTime), path: '/' });
    checkTokenExpiry();
}

function getToken() {
    return Cookies.get('token');
}
function getTokenExpiry() {
    return Cookies.get('token_expiry');
}
function checkTokenExpiry() {
    var token = getToken();
    if (!token) {
        loginPopup();
        return;
    }

    var tokenExpiry = new Date().getTime() - 24 * 60 * 60 * 1000; // token expires after 24 hours
    if (tokenExpiry > getTokenExpiry()) {
        // token has expired, refresh the token
        loginPopup();
    }
}