﻿$(document).ready(function () {
    PopulateStartDate();
    // Fetch doctor names and populate the dropdown
    fetchDoctorNames();

});

// Function to fetch data from the API
function fetchData() {
    var apiUrl = '/Rajor/GetPatientRecords';
    fetchDataAndUpdateTable(apiUrl, createTable);
}
// Function to fetch and populate doctor names
function fetchDoctorNames() {
    var apiUrl = '/Rajor/GetDoctorNames';
    fetchDataAndUpdateTable(apiUrl, populateDoctorDropdown);
}

function populateDoctorDropdown(doctorNames) {
    var doctorSelect = $('#DoctorFilter');
    doctorSelect.empty();

    doctorSelect.append($('<option>', {
        value: '',
        text: 'All Doctors'
    }));

    doctorNames.forEach(function (doctorName) {
        doctorSelect.append($('<option>', {
            value: doctorName,
            text: doctorName
        }));
    });

    // Initialize Select2 after updating options
    doctorSelect.select();
    fetchData();;
}

// Function to create the table based on the JSON data
function createTable(data) {
    for (var k = 0; k < data.length; k++) {
        data[k].Date = new Date(parseInt(data[k].Date.substring(6, 19)));
    }

    // Calculate the total amount
    var totalAmount = data.reduce(function (total, entry) {
        return total + entry.Amount;
    }, 0);

    // Calculate the total amount
    var cashAmount = data.reduce(function (total, entry) {
        if (entry.PaymentMethod == "cash")
            return total + entry.Amount;
        else
            return total + 0;
    }, 0);

    // Calculate the total amount
    var onlineAmount = data.reduce(function (total, entry) {
        if (entry.PaymentMethod == "online")
            return total + entry.Amount;
        else
            return total + 0;
    }, 0);

    const formatter = new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2, });

    const totalAmountString = formatter.format(totalAmount);

    document.getElementById("totalAmount").textContent = totalAmountString;
    // Update the total amount in the HTML
    document.getElementById("CashAmount").textContent = formatter.format(cashAmount);
    // Update the total amount in the HTML
    document.getElementById("OnlineAmount").textContent = formatter.format(onlineAmount);
    // Group data by DoctorName
    var groupedData = {};
    data.forEach(function (item) {
        if (!groupedData[item.DoctorName]) {
            groupedData[item.DoctorName] = [];
        }
        groupedData[item.DoctorName].push(item);
    });

    // Create tables for each doctor
    $('#tblPatient').html("");
    $.each(groupedData, function (doctorName, appointments) {
        var table = $('<table style="width:100%">').appendTo('#tblPatient');
        var caption = $('<caption>').text(doctorName).appendTo(table);
        caption.addClass('mt-2');
        caption.addClass('caption2');

        var tbody = $('<tbody>').appendTo(table);
        var tfoot = $('<tfoot>').appendTo(table);
        var sumAmount = 0;

        $('<tr>').append($('<th>').text('Date'), $('<th>').text('Count'), $('<th>').text('Amount')).appendTo(tbody);
        var options = { day: '2-digiFt', month: 'short', year: 'numeric' };

        var existingDates = [];

        $.each(appointments, function (index, appointment) {
            var formattedDate = formatDate(appointment.Date);

            if (!existingDates.includes(formattedDate)) {
                $('<tr>').append($('<td>').text(formattedDate), $('<td>').text(appointment.TotalCount), $('<td>').text(appointment.Amount + '.00')).appendTo(tbody);
                existingDates.push(formattedDate);
            } else {
                var existingRow = tbody.find('tr').filter(function () {
                    return $(this).find('td:eq(0)').text() === formattedDate;
                });
                var existingCount = parseInt(existingRow.find('td:eq(1)').text());
                var existingAmount = parseFloat(existingRow.find('td:eq(2)').text().replace('.00', ''));
                existingRow.find('td:eq(1)').text(existingCount + appointment.TotalCount);
                existingRow.find('td:eq(2)').text((existingAmount + appointment.Amount) + '.00');
            }

            sumAmount += appointment.Amount;
        });

        $('<tr>').append($('<td>').text(''), $('<td>').text('Total'), $('<td>').text(sumAmount + '.00')).appendTo(tfoot);
        caption.css('caption-side', 'top');
    });
}

// Function to format date in "dd-MMM-yyyy" format
function formatDate(date) {
    var options = { day: '2-digit', month: 'short', year: 'numeric' };
    var formattedDate = date.toLocaleDateString('en-US', options);
    var parts = formattedDate.replace(',', '').split(' ');
    return parts[1] + '-' + parts[0] + '-' + parts[2];
}

function PopulateStartDate() {
    // Get the current date
    var currentDate = new Date();

    // Calculate the date 12 months ago
    //currentDate.setMonth(currentDate.getMonth() - 12);

    // Extract year and month from the calculated date
    var year = currentDate.getFullYear();
    var month = currentDate.getMonth() + 1; // Adding 1 because getMonth() returns a zero-based month
    var date = currentDate.getDate();
    if (date < 10)
        date = "0" + date;

    // Ensure the month is in tw(o-digit format (e.g., "01" for January)
    if (month < 10)
        month = "0" + month;

    // Construct the formatted start date string in the "YYYY-MM-DD" format
    var formattedStartDate = year + "-" + month + "-01";

    // Construct the formatted start date string in the "YYYY-MM-DD" format
    var formattedEndDate = year + "-" + month + "-" + date;

    // Set the "startDate" input field value
    $("#startDate").val(formattedStartDate);
    $("#endDate").val(formattedEndDate);

}


function PopulateEndDate() {
    var currentDate = new Date();
    // Get the value of "endDate" from the query string
    var endDateFromQueryString = getParameterByName('endDate');

    // If "endDate" is present in the query string, set it as the input field value
    if (endDateFromQueryString !== null) {
        $("#endDate").val(endDateFromQueryString);
    } else {
        // If not found in the query string, set the default "End Date" to the last day of the current month
        var lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

        // Corrected formatting to get the last day of the month
        var formattedEndDate = lastDayOfMonth.getFullYear() + '-' + ('0' + (lastDayOfMonth.getMonth() + 1)).slice(-2) + '-' + ('0' + lastDayOfMonth.getDate()).slice(-2);

        $("#endDate").val(formattedEndDate);
    }
}

function exportTableToPdfPatient() {
    window.jsPDF = window.jspdf.jsPDF;
    console.log("HI")

    // Assuming startDate and endDate are in yyyy-MM-dd format
    var formattedStartDate = fileFormatDate($("#startDate").val());
    var formattedEndDate = fileFormatDate($("#endDate").val());

    // Create the file name based on the start date and end date
    var fileName = `${formattedStartDate}_${formattedEndDate}.pdf`;

    // Create a new jsPDF instance
    var pdf = new jsPDF();
    function header() {
        pdf.setFontSize(22);
        pdf.setFont("Helvetica", "Bold")
        pdf.setTextColor(255, 165, 0)
        pdf.text("MAHANT SHRI SATISH DASS JI", 60, 13);
        pdf.setFontSize(17);
        pdf.setFont("Helvetica", "Bold")
        pdf.setTextColor(0, 0, 0)
        pdf.text("CHARITABLE FOUNDATION", 61, 19);
        console.log("ghgm")
        pdf.setFontSize(24);
        pdf.setFont("Helvetica", "Bold")
        pdf.setTextColor(0, 0, 0)
        var txt = "Patient Transaction Summary"
        pdf.text(txt, 50, 30);
        pdf.line(0, 40, 250, 40)
        pdf.addImage('/Images/GuruJiImage.jpg', 'JPEG', 50, 10, 100, 100)
    }
    header()
    window.html2canvas = html2canvas;

    const data = document.getElementById('patienDetailInfoFull');
    html2canvas(data).then((canvas) => {

        const imgWidth = 208;
        const pageHeight = 295;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        let heightLeft = imgHeight;
        let position = 0;
        heightLeft -= pageHeight;
        const doc = new jsPDF('p', 'mm');
        doc.addImage(canvas, 'PNG', 0, position, imgWidth, imgHeight, '', 'FAST');

        while (heightLeft >= 0) {
            position = heightLeft - imgHeight;
            doc.addPage();
            doc.addImage(canvas, 'PNG', 0, position, imgWidth, imgHeight, '', 'FAST');
        }
        // Save the PDF
        doc.save(fileName);

    });
}