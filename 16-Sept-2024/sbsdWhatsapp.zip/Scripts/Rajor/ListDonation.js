﻿$(document).ready(function () {

    PopulateStartDate();
    PopulateEndDate();

    // Fetch data from the API on page load
    fetchData();
});


// Handle click events on the "Close" button in the modal header
function closeButtonAction() {
    // Toggle back to the detail view
    toggleDetailView(false);
}

// Function to collect and submit all rows data
function submitAllRowsData() {
    var rowDataArray = JSON.stringify({
        SlipDate: $("[id = 'editSlip Date']").val(),
        Address: $('#editAddress').val(),
        SerialNumber: $("[id = 'editSerial Number']").val(),
        MobileNumber: $('#editMobile').val(),
        EmailAddress: $('#editEmail').val(),
        Amount: parseInt($('#editAmount').val()),
        Name: $('#editName').val(),
        PanCard: $('#editPanCard').val(),
        id: $('#editID').val()
    });

    // Send the collected data to the server using an AJAX request
    $.ajax({
        url: '/Rajor/UpdateData', // Replace with your server endpoint URL
        method: 'POST',
        contentType: 'application/json',
        data: rowDataArray,
        success: function (response) {
            // Handle success response from the server
            console.log('Data submitted successfully:', response);
        },
        error: function (error) {
            // Handle error response from the server
            console.error('Error submitting data:', error);
        }
    });
}


function updateGridFromForm() {
    // Update the detail view
    var detailViewContent = '';
    var cellIndex = 0;
    var editId = $('#editID').val();
    // Loop through all rows in the edit form
    $('#editForm div').each(function () {
        var row = $(this);
        var label = row.find('label').text(); // Get the label text
        var value = row.find('input').val(); // Get the input value
        if (label == "Address")
            detailViewContent += "<strong>" + label + ":</strong> " + $('#editAddress').val() + "<br>";
        else
            detailViewContent += "<strong>" + label + ":</strong> " + value + "<br>";



        // Update the corresponding cell in the grid
        $('#tableDonation tbody tr').each(function () {
            var gridRow = $(this);

            var cell = gridRow.find('td').eq(9);

            // Update the cell content in the grid
            if (cell.text() == editId) {
                var cell = gridRow.find('td').eq(cellIndex);

                // Update the cell content in the grid
                if (label == "Name")
                    cell.html('<a href="#" class="name-link">' + value + '</a>');
                else if (label == "Slip Date")
                    cell.html('<a href="/Rajor/GeneratePdf?id=' + editId + '" class="date-link" data-id="' + editId + '">' + value + '</a>');
                else
                    cell.text(value);
            }
        });

        cellIndex++;
    });

    // Update the detail view content
    $("#detailView").html(detailViewContent);
}

// Handle click events on the "Edit" button in the modal
function editButtonAction() {
    // Toggle to the edit form view
    toggleDetailView(true);
}

// Handle click events on the "Save" button in the modal
function saveButtonAction() {
    // Implement your logic to save the edited data here
    // Retrieve the edited data from the form fields and send it to the server
    submitAllRowsData();

    updateGridFromForm();

    // After saving, toggle back to the detail view
    toggleDetailView(false);
}

function sendReceiptToUser() {
    // Get the ID of the payment record for which to send the receipt
    var paymentId = $("#detailPaymentId").text(); // Assuming you have an element with the ID "detailPaymentId" to store the payment ID

    // Show the modal and full-page overlay
    $('#rowDataModal').modal('show');
    $("#overlay").show();

    // Make an AJAX request to the /Rajor/SendEmail endpoint
    var paymentId = $("#editId").val(); // Assuming you have an element with the ID "detailPaymentId" to store the payment ID
    $.ajax({
        url: '/Rajor/SendEmail?id=' + paymentId,
        method: 'Get',
        success: function () {
            // Close the modal and hide the overlay on success
            $('#rowDataModal').modal('hide');
            $("#overlay").hide();

            // Display the success alert message
            $("#successAlert").fadeIn(300).delay(3000).fadeOut(300); // Show for 3 seconds

            // Optionally, you can perform additional actions on success
        },
        error: function () {
            // Close the modal and hide the overlay on error
            $('#rowDataModal').modal('hide');
            $("#overlay").hide();

            // Display the error alert message
            $("#errorAlert").fadeIn(300).delay(3000).fadeOut(300); // Show for 3 seconds

            // Optionally, you can perform error handling
        }
    });
}

// Function to populate the edit form HTML with data
function populateEditFormHtml(editRowData) {
    // Initialize the edit form HTML
    var editFormHtml = '';

    // Loop through the row data for each column
    for (var i = 0; i < editRowData.length; i++) {
        var columnHeader = editRowData[i].columnHeader;
        var cellData = editRowData[i].cellData;

        // Generate the form input field based on the column data
        editFormHtml += '<div class="mb-3">';
        editFormHtml += '<label for="edit' + columnHeader + '" class="form-label">' + columnHeader + '</label>';

        // Check if the column header is "Address" and create a textarea input
        if (columnHeader === 'Address') {
            editFormHtml += '<textarea class="form-control" id="edit' + columnHeader + '" name="edit' + columnHeader + '">' + cellData + '</textarea>';
        } else {
            editFormHtml += '<input type="text" class="form-control" id="edit' + columnHeader + '" name="edit' + columnHeader + '" value="' + cellData + '"';

            // Check if the column header is "Payment ID" or "ID" and add the disabled attribute
            if (columnHeader === 'Payment ID' || columnHeader === 'ID' || columnHeader == "Createdon") {
                editFormHtml += ' disabled';
            }

            editFormHtml += '>';
        }

        editFormHtml += '</div>';
    }

    // Set the inner HTML of the editForm to the generated HTML
    $("#editForm").html(editFormHtml);
}

function PopulateStartDate() {
    // Get the value of "startDate" from the query string
    var startDateFromQueryString = getParameterByName('startDate');

    // If "startDate" is present in the query string, set it as the input field value
    if (startDateFromQueryString !== null) {
        $("#startDate").val(startDateFromQueryString);
    } else {
        // If not found in the query string, set it to the first day of the current month
        var currentDate = new Date();

        var month = currentDate.getMonth();
        month = month + 1;
        if (month < 10)
            month = "0" + month;
        var formattedStartDate = currentDate.getFullYear() + "-" + month + "-01";

        // Set the "startDate" input field value
        $("#startDate").val(formattedStartDate);
    }
}

function PopulateEndDate() {
    var currentDate = new Date();
    // Get the value of "endDate" from the query string
    var endDateFromQueryString = getParameterByName('endDate');

    // If "endDate" is present in the query string, set it as the input field value
    if (endDateFromQueryString !== null) {
        $("#endDate").val(endDateFromQueryString);
    } else {
        // If not found in the query string, set the default "End Date" to the last day of the current month
        var lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

        // Corrected formatting to get the last day of the month
        var formattedEndDate = lastDayOfMonth.getFullYear() + '-' + ('0' + (lastDayOfMonth.getMonth() + 1)).slice(-2) + '-' + ('0' + lastDayOfMonth.getDate()).slice(-2);

        $("#endDate").val(formattedEndDate);
    }
}

function downloadPdfFromEditForm() {
    // Get the ID of the payment record for which to generate the PDF
    var paymentId = $("#editId").val(); // Assuming you have an element with the ID "detailPaymentId" to store the payment ID

    // Construct the PDF download URL with the payment ID
    var pdfDownloadUrl = '/Rajor/GeneratePdf?id=' + paymentId;

    // Trigger the PDF download by redirecting the user to the PDF download URL
    window.location.href = pdfDownloadUrl;
}

// Function to fetch data from the API
function fetchData() {
    var apiUrl = '/Rajor/GetListData';
    fetchDataAndUpdateTable(apiUrl, createTable);
}

// Function to create the table based on the JSON data
function createTable(data) {
    for (var k = 0; k < data.length; k++) {
        data[k].Createdon = new Date(parseInt(data[k].Createdon.substring(6, 19)));
        data[k].SlipDate = new Date(parseInt(data[k].SlipDate.substring(6, 19)));
    }

    var arrayTable = [
        { DisplayName: "Name,", FieldName: "Name", Type: "text", FooterLabel: "Total:", IsHyperLink: true, cssClass: "name-link" },
        { DisplayName: "Amount", FieldName: "Amount", Type: "float", cssClass: "text-right", IsSumRequired: true },
        { DisplayName: "Mobile Number", FieldName: "MobileNumber", Type: "text" },
        { DisplayName: "Slip Date", FieldName: "SlipDate", Type: "date" },
        { DisplayName: "Email Address", FieldName: "EmailAddress", Type: "text", cssClass: "displaynone" },
        { DisplayName: "Pan Card", FieldName: "PanCard", Type: "text", cssClass: "displaynone" },
        { DisplayName: "Address", FieldName: "Address", Type: "text", cssClass: "displaynone" },
        { DisplayName: "Serial Number", FieldName: "SerialNumber", Type: "text", cssClass: "displaynone" },
        { DisplayName: "Payment Id", FieldName: "PaymentId", Type: "text", cssClass: "displaynone" },
        { DisplayName: "Id", FieldName: "id", Type: "text", cssClass: "displaynone" },
        { DisplayName: "Date Created", FieldName: "Createdon", Type: "datetime", cssClass: "date-link", cssClass: "displaynone", Sorting: true },
    ];
    createDataTable(arrayTable, data);


    // Handle click events on the "Name" links to show row data in a modal
    $("#tableDonation tbody").on("click", ".name-link", function () {
        var rowData = $(this).closest("tr").find("td:not(.hiddenFromExport)").map(function (index) {
            var columnHeader = $("#tableDonation th").eq(index).text();
            var cellData = $(this).text();
            return "<strong>" + columnHeader + ":</strong> " + cellData;
        }).get();

        var editRowData = $(this).closest("tr").find("td:not(.hiddenFromExport)").map(function (index) {
            var columnHeader = $("#tableDonation th").eq(index).text();
            var cellData = $(this).text();
            return {
                columnHeader: columnHeader,
                cellData: cellData
            };
        }).get();

        var editRowData = $(this).closest("tr").find("td:not(.hiddenFromExport)").map(function (index) {
            var columnHeader = $("#tableDonation th").eq(index).text();
            var cellData = $(this).text();
            return {
                columnHeader: columnHeader,
                cellData: cellData
            };
        }).get();

        populateEditFormHtml(editRowData);


        var modalContent = rowData.join("<br>");

        // Set the content and title of the modal
        $("#detailView").html(modalContent);
        $("#rowDataModalLabel").text("Payment Detail");

        // Toggle to the detail view initially
        toggleDetailView(false);

        // Show the modal
        $("#rowDataModal").modal("show");
    });
}

// Function to toggle between detail view and edit form view
function toggleDetailView(editMode) {
    if (editMode) {
        $("#detailView").hide(); // Hide detail view
        $("#editForm").show(); // Show edit form
        $("#editButton").hide(); // Hide the "Edit" button
        $("#saveButton").show(); // Show the "Save" button
        $("#downloadPdfButton").hide(); // Show the "Save" button
        $("#sendReceiptButton").hide(); // Show the "Save" button
        $("#rowDataModalLabel").text("Edit Payment"); // Change modal title
    } else {
        $("#detailView").show(); // Show detail view
        $("#editForm").hide(); // Hide edit form
        $("#editButton").show(); // Show the "Edit" button
        $("#saveButton").hide(); // Hide the "Save" button
        $("#downloadPdfButton").show(); // Show the "Save" button
        $("#sendReceiptButton").show(); // Show the "Save" button
        $("#rowDataModalLabel").text("Payment Detail"); // Change modal title
    }
}