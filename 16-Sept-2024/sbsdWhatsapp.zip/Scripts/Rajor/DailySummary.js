﻿$(document).ready(function () {
    $('.dropdown-toggle').dropdown();
    // Hide the no records message initially
    $("#noRecordsMessage").hide();
    PopulateStartDate();
    PopulateEndDate();
    // Fetch data from the API on page load
    fetchData();
});

// Function to fetch data from the API
function fetchData() {
    var apiUrl = '/Rajor/GetDailySummary';
    fetchDataAndUpdateTable(apiUrl, createTable);
}

// Function to create the table based on the JSON data
function createTable(data) {
    for (var k = 0; k < data.length; k++) {
        var oldDate2 = data[k].Date.split(' ');
        var oldDate = oldDate2[0].split('-');
        // Subtract 1 from the month since months are zero-based in JavaScript Date
        var newDateValue = new Date(oldDate[2], oldDate[1] - 1, oldDate[0]);
        data[k].NewDateColumn = newDateValue;
    }
    console.log(data);
    var arrayTable = [
        { DisplayName: "Date", FieldName: "NewDateColumn", Type: "date", FooterLabel: "Total:", IsHyperLink: true, cssClass: "date-link" },
        { DisplayName: "Count", FieldName: "TransactionCount", Type: "int", IsSumRequired: true },
        { DisplayName: "Amount", FieldName: "Amount", Type: "float", IsSumRequired: true, cssClass: "text-right" },
    ];

    createDataTable(arrayTable, data);

    // Handle click events on the "Name" links to show row data in a modal
    $("#tableDonation tbody").on("click", ".date-link", function () {
        inputDate = $(this).text()
        // Split the input date into day, month, and year
        var dateParts = inputDate.split('-');
        var day = parseInt(dateParts[0]);
        var month = dateParts[1];
        var year = parseInt(dateParts[2]);

        // Define a mapping of month names to their numeric values
        var monthMap = {
            "Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4,
            "May": 5, "Jun": 6, "Jul": 7, "Aug": 8,
            "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12
        };

        // Get the numeric month value from the month name
        month = monthMap[month];

        if (month < 10)
            month = '0' + month;
        if (day < 10)
            day = '0' + day;
        // Format the date as "yyyy-mm-dd"
        var formattedDate = year + "-" + month + "-" + day;
        window.location.href = "/Rajor/Index?startDate=" + formattedDate + "&endDate=" + formattedDate;
    });
}

function PopulateStartDate() {
    // Get the value of "startDate" from the query string
    var startDateFromQueryString = getParameterByName('startDate');

    // If "startDate" is present in the query string, set it as the input field value
    if (startDateFromQueryString !== null) {
        $("#startDate").val(startDateFromQueryString);
    } else {
        // If not found in the query string, set it to the first day of the current month
        var currentDate = new Date();

        var month = currentDate.getMonth();
        month = month + 1;
        if (month < 10)
            month = "0" + month;
        var formattedStartDate = currentDate.getFullYear() + "-" + month + "-01";

        // Set the "startDate" input field value
        $("#startDate").val(formattedStartDate);
    }
}

function PopulateEndDate() {
    var currentDate = new Date();
    // Get the value of "endDate" from the query string
    var endDateFromQueryString = getParameterByName('endDate');

    // If "endDate" is present in the query string, set it as the input field value
    if (endDateFromQueryString !== null) {
        $("#endDate").val(endDateFromQueryString);
    } else {
        // If not found in the query string, set the default "End Date" to the last day of the current month
        var lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

        // Corrected formatting to get the last day of the month
        var formattedEndDate = lastDayOfMonth.getFullYear() + '-' + ('0' + (lastDayOfMonth.getMonth() + 1)).slice(-2) + '-' + ('0' + lastDayOfMonth.getDate()).slice(-2);

        $("#endDate").val(formattedEndDate);
    }
}
