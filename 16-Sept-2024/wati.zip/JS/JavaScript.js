﻿for (var l = 0; l < tg.length; l++) {
    if (lhList[t[i].token] == undefined) {
        lhList[t[i].token] = t[i];
    } else if (lhList[t[i].token].highPrice != t[i].highPrice) {
        console.log("high break" + tg[i].token);
    }
    else if (lhList[t[i].token].lowPrice != t[i].lowPrice) {
        console.log("low break" + tg[i].token);
    } else {
        console.log("none");
    }
}


if (lhList[t[i].token] == undefined) {
    lhList[t[i].token] = t[i];
} else if (lhList[t[i].token].highPrice != t[i].highPrice) {
    console.log("high break" + tg[i].token);
}
else if (lhList[t[i].token].lowPrice != t[i].lowPrice) {
    console.log("low break" + tg[i].token);
}