﻿$(document).ready(function () {
    // 1. Create a new XMLHttpRequest object
    let xhr = new XMLHttpRequest();

    // 2. Configure it: GET-request for the URL 'menu.html'
    xhr.open('GET', 'menu.html');

    // 3. Send the request over the network
    xhr.send();

    // 4. This will be called after the response is received
    xhr.onload = function () {
        if (xhr.status === 200) {
            // Check if the request was successful
            let data = xhr.responseText; // Get the response data
            const body = document.body; // Get a reference to the body element
            body.insertAdjacentHTML('afterbegin', data); // Prepend the data to the body
        } else {
            console.error('Request failed with status', xhr.status);
        }
    };


    var table = null; // Variable to store DataTable instance

    // Hide the no records message initially
    $("#noRecordsMessage").hide();

    // Set the default "Start Date" to the first day of the current month
    var currentDate = new Date();
    var firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    var formattedStartDate = firstDayOfMonth.toISOString().substring(0, 10);
    $("#startDate").val(formattedStartDate);
    setStartDateFromQueryString();

    // Set the default "End Date" to the last day of the current month
    var lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    var formattedEndDate = lastDayOfMonth.toISOString().substring(0, 10);
    $("#endDate").val(formattedEndDate);

    // Function to update the total amount in the footer
    function updateTotalAmount() {
        var totalAmount = table
            .column(3, { search: 'applied' }) // Column index of "Amount"
            .data()
            .reduce(function (acc, val) {
                var amount = parseFloat(val.replace('$', '').replace(',', ''));
                return acc + amount;
            }, 0);

        $("#totalAmount").text(formatAmount(totalAmount.toFixed(2)));
        table.draw(); // Redraw the table to update the footer
    }

    // Function to fetch data from the API
    function fetchData() {
        // Get the current URL
        var currentUrl = window.location.href;

        // Define the API endpoint without the prefix
        var apiUrl = '/RajorPay/GetDailySummary';

        // Check if the current URL contains the prefix
        if (currentUrl.includes('ersandeeppruthi')) {
            // Add the prefix to the API endpoint
            apiUrl = '/ersandeeppruthi' + apiUrl;
        }

        $("#overlay").show();

        // Make an AJAX request to the API (replace with your actual API endpoint)
        $.ajax({
            url: apiUrl,
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                startDate: $("#startDate").val(),
                endDate: $("#endDate").val()
            }),
            success: function (data) {
                // Call createTable to update the table with the API response data
                createTable(data);
                $("#overlay").hide();
            },
            error: function (error) {
                // Handle any errors from the API request
                console.error('Error:', error);
                alert('An error occurred while fetching data from the API.');
                $("#overlay").hide();
            }
        });
    }

    // Fetch data from the API on page load
    fetchData();

    // Handle click event on the "Search" button
    $("#searchButton").click(function () {
        // Fetch data from the API when the "Search" button is clicked
        fetchData();
    });

    // Function to create the table based on the JSON data
    function createTable(data) {
        if (table) {
            // If DataTable is already initialized, destroy it before reinitializing
            table.destroy();
        }

        table = $('#transactionTable').DataTable({
            "paging": false,
            "searching": false, // Disable searching
            "order": [[0, "desc"]], // Sort by column index 0 (Date) in descending order
            "columnDefs": [
                {
                    targets: 0, // The column index of "Date"
                    render: function (data, type, row) {
                        // Format the date as "dd-MMM-yyyy"
                        if (type === "sort" || type === "type") {
                            // For sorting and type detection, return a date string in the format "yyyy-mm-dd"
                            return new Date(data.replace(/(\d{2})-(\w{3})-(\d{4})/, "$3-$2-$1"));
                        } else {
                            // For display, return the original formatted date
                            return formatDate(data);
                        }
                    }
                },
                {
                    targets: 2, // Index of the "TotalAmount" column (zero-based)
                    render: function (data, type, row) {
                        // Format the amount as desired (e.g., add currency symbol)
                        return formatAmount(data);
                    }
                }
            ],
            "footerCallback": function (row, data, start, end, display) {
                var api = this.api();

                // Calculate the total amount
                var totalAmount = api
                    .column(2, { search: 'applied' }) // Column index of "TotalAmount"
                    .data()
                    .reduce(function (acc, val) {
                        if (typeof val === 'string') {
                            // If val is a string, replace commas and convert to a floating-point number
                            val = parseFloat(val.replace(/,/g, ''));
                        }
                        return acc + val;
                    }, 0);

                // Update the "Total" cell in the footer row
                $(api.column(2).footer()).html(formatAmount(totalAmount));

            },
            "responsive": true // Enable DataTables responsive feature
        });

        // Clear existing table data
        table.clear().draw();

        // Loop through the API response data and add rows to the table
        for (var i = 0; i < data.length; i++) {
            var rowData = data[i];

            // Add the row to the table
            var row = table.row.add([
                formatDate(rowData.Date),  // Date field from the API response
                rowData.TransactionCount,  // Transaction Count field from the API response
                rowData.TotalAmount  // Total Amount field from the API response
            ]).draw(false).node();
        }

        // Update the total amount in the footer
        //updateTotalAmount();

        // Hide the "No records found" message if data is available
        $("#noRecordsMessage").hide();
    }

    // Function to format date as "dd-MMM-yyyy"
    function formatDate(dateString) {
        var date = new Date(dateString);
        var day = date.getDate();
        var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        var monthIndex = date.getMonth();
        var year = date.getFullYear();
        return day + "-" + monthNames[monthIndex] + "-" + year;
    }
    // Export button click event handler
    $("#exportCsvButton").click(function () {
        // Get the DataTable instance
        var dataTable = $('#transactionTable').DataTable();

        // Get the filtered data from the DataTable
        var filteredData = dataTable.rows({ filter: 'applied' }).data();

        // Assuming startDate and endDate are in yyyy-MM-dd format
        var formattedStartDate = formatDate($("#startDate").val());
        var formattedEndDate = formatDate($("#endDate").val());

        // Create the file name based on the start date and end date
        var fileName = `${formattedStartDate}_${formattedEndDate}.csv`;

        // Create a CSV string to store the filtered table data
        var csv = '';

        // Get the table headers
        var headers = [];
        $('#transactionTable th').each(function () {
            headers.push('"' + $(this).text() + '"');
        });
        csv += headers.join(',') + '\n';

        // Iterate through the filtered data and add rows to the CSV
        filteredData.each(function (rowData) {
            var rowDataArray = [];
            rowDataArray.push('"' + rowData[0] + '"'); // Handle "Name" column separately
            for (var i = 1; i < rowData.length; i++) {
                rowDataArray.push('"' + rowData[i] + '"');
            }
            csv += rowDataArray.join(',') + '\n';
        });

        // Create a Blob (file) from the CSV data
        var blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });

        // Save the Blob as a file using FileSaver.js
        saveAs(blob, fileName);
    });


    function exportTableToPdf() {
        window.jsPDF = window.jspdf.jsPDF;

        // Get the DataTable instance
        var dataTable = $('#transactionTable').DataTable();

        // Assuming startDate and endDate are in yyyy-MM-dd format
        var formattedStartDate = formatDate($("#startDate").val());
        var formattedEndDate = formatDate($("#endDate").val());

        // Create the file name based on the start date and end date
        var fileName = `${formattedStartDate}_${formattedEndDate}.pdf`;

        // Create a new jsPDF instance
        var pdf = new jsPDF();


        // Define the columns and data (including the footer row)
        var columns = ["Date", "Count", "Amount"];
        var data = [];

        // Iterate through the table rows and add data to the data array
        $('#transactionTable tbody tr').each(function () {
            var rowData = [];
            $(this).find('td').each(function () {
                rowData.push($(this).text());
            });
            data.push(rowData);
        });

        // Calculate the total amount
        var totalAmount = data.reduce(function (sum, row) {
            return sum + parseFloat(row[2].replace(/[^\d.]/g, ''));
        }, 0);

        // Add the footer row with the total amount
        data.push(["Total:", "", formatAmount(totalAmount)]);

        // Set up the PDF document
        pdf.autoTable({
            head: [columns],
            body: data,
            theme: 'striped',
            margin: { top: 20, left: 10, right: 10, bottom: 10 },
            didDrawPage: function (data) {
                // Add a footer with the date
                var dateFormat = "dd-MM-yyyy";
                var date = new Date();
                var formattedDate = date.toLocaleDateString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
                pdf.text(formattedDate, data.settings.margin.left, pdf.internal.pageSize.height - 10);
            },
        });

        // Save the PDF
        pdf.save(fileName);

    }

    // Handle click events on the "Export PDF" button
    $("#exportPdfButton").click(function () {
        // Export table data to PDF when the button is clicked
        exportTableToPdf();
    });

});

function getQueryParam(name) {
    const urlSearchParams = new URLSearchParams(window.location.search);
    return urlSearchParams.get(name);
}

function setStartDateFromQueryString() {
    const startDateParam = getQueryParam('startDate');
    if (startDateParam) {
        // If the query string parameter exists, set the input value
        $("#startDate").val(startDateParam);
    } else {
        // If not, use the default logic to set the first day of the current month
        var currentDate = new Date();
        var firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
        var formattedStartDate = firstDayOfMonth.toISOString().substring(0, 10);
        $("#startDate").val(formattedStartDate);
    }
}

function formatAmount(amount) {
    // Convert the amount to a floating-point number if it's a string
    var parsedAmount = parseFloat(amount);

    // Check if the parsedAmount is a valid number
    if (!isNaN(parsedAmount)) {
        // Use the toLocaleString method to format the number as currency
        return parsedAmount.toLocaleString('en-IN', {
            style: 'currency',
            currency: 'INR'
        }).replace('₹', ''); // Remove the rupee symbol
    } else {
        // Return the original input if parsing fails
        return amount;
    }
}

function fileFormatDate(dateString) {
    var parts = dateString.split('-');
    var year = parts[0].slice(-2); // Get the last 2 digits of the year
    var month = new Date(Date.parse(dateString + 'T00:00:00')).toLocaleString('en-us', { month: 'short' });
    var day = parts[2];

    return `${day}-${month}-${year}`;
}

// Function to export table data to Excel
function exportTableToExcel() {
    // Get the DataTable instance
    var dataTable = $('#transactionTable').DataTable();

    // Assuming startDate and endDate are in yyyy-MM-dd format
    var formattedStartDate = fileFormatDate($("#startDate").val());
    var formattedEndDate = fileFormatDate($("#endDate").val());

    // Create the file name based on the start date and end date
    var fileName = `${formattedStartDate}_${formattedEndDate}.xlsx`;

    // Get the filtered data from the DataTable
    var filteredData = dataTable.rows({ filter: 'applied' }).data();

    // Create an array to store table headers
    var headers = $('#transactionTable thead th').map(function () {
        return $(this).text();
    }).toArray();

    // Create an array of data rows
    var dataRows = [headers].concat(filteredData.toArray());

    // Create a new workbook and add a worksheet
    var wb = XLSX.utils.book_new();
    var ws = XLSX.utils.aoa_to_sheet(dataRows);

    // Add the worksheet to the workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    // Save the workbook as an Excel file
    XLSX.writeFile(wb, fileName);
}

// Handle click events on the "Export Excel" button
$("#exportExcelButton").click(function () {
    // Export table data to Excel when the button is clicked
    exportTableToExcel();
});


// Function to export table data to PDF


