﻿$(document).ready(function () {
    $('.dropdown-toggle').dropdown();
    // Hide the no records message initially
    $("#noRecordsMessage").hide();
});

var table = null; // Variable to store DataTable instance
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

function fileFormatDate(dateString) {
    var parts = dateString.split('-');
    var year = parts[0].slice(-2); // Get the last 2 digits of the year
    var month = new Date(Date.parse(dateString + 'T00:00:00')).toLocaleString('en-us', { month: 'short' });
    var day = parts[2];

    return `${day}-${month}-${year}`;
}


function formatAmount(amount) {
    // Convert the amount to a floating-point number if it's a string
    var parsedAmount = parseFloat(amount);

    // Check if the parsedAmount is a valid number
    if (!isNaN(parsedAmount)) {
        // Use the toLocaleString method to format the number as currency
        return parsedAmount.toLocaleString('en-IN', {
            style: 'currency',
            currency: 'INR'
        }).replace('₹', ''); // Remove the rupee symbol
    } else {
        // Return the original input if parsing fails
        return amount;
    }
}



function exportToCSV() {
    // Assuming startDate and endDate are in yyyy-MM-dd format
    var formattedStartDate = fileFormatDate($("#startDate").val());
    var formattedEndDate = fileFormatDate($("#endDate").val());

    // Create the file name based on the start date and end date
    var fileName = `${formattedStartDate}_${formattedEndDate}.csv`;
    var csv = "";
    // Get the table headers
    var headers = [];
    $('#tableDonation thead th:not(.hiddenFromExport)').each(function () {
        headers.push('"' + $(this).text() + '"');
    });
    csv += headers.join(',') + '\n';

    // Iterate through the table rows and add data to the data array
    $('#tableDonation tbody tr:visible').each(function () {
        var rowData = [];
        $(this).find('td:not(.hiddenFromExport)').each(function () {
            rowData.push('"' + $(this).text() + '"');
        });
        csv += rowData.join(',') + '\n';
    });

    // Iterate through the table rows and add data to the data array
    $('#tableDonation tfoot tr:visible').each(function () {
        var rowData = [];
        $(this).find('th:not(.hiddenFromExport)').each(function () {
            rowData.push('"' + $(this).text() + '"');
        });
        csv += rowData.join(',') + '\n';
    });

    // Create a Blob (file) from the CSV data
    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });

    // Save the Blob as a file using FileSaver.js
    saveAs(blob, fileName);
}


function exportTableToExcel() {
    // Assuming startDate and endDate are in yyyy-MM-dd format
    var formattedStartDate = fileFormatDate($("#startDate").val());
    var formattedEndDate = fileFormatDate($("#endDate").val());

    // Create the file name based on the start date and end date
    var fileName = `${formattedStartDate}_${formattedEndDate}.xlsx`;

    // Create an array to store table headers
    var headers = [];
    $('#tableDonation thead th:not(.hiddenFromExport)').each(function () {
        headers.push($(this).text());
    });

    var data = [];

    // Iterate through the table rows and add data to the data array
    $('#tableDonation tbody tr:visible').each(function () {
        var rowData = [];
        $(this).find('td:not(.hiddenFromExport)').each(function () {
            rowData.push($(this).text());
        });
        data.push(rowData);
    });

    // Iterate through the table rows and add data to the data array
    $('#tableDonation tfoot tr').each(function () {
        var rowData = [];
        $(this).find('th:not(.hiddenFromExport)').each(function () {
            rowData.push($(this).text());
        });
        data.push(rowData);
    });

    // Create an array of data rows with headers
    var dataRows = [headers].concat(data);

    // Create a new workbook and add a worksheet
    var wb = XLSX.utils.book_new();
    var ws = XLSX.utils.aoa_to_sheet(dataRows);

    // Autofit column widths
    var wscols = [];
    headers.forEach(function (header) {
        wscols.push({ wch: header.length + 5 }); // You can adjust the value added to the column width as needed
    });
    ws['!cols'] = wscols;

    // Add the worksheet to the workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    // Save the workbook as an Excel file
    XLSX.writeFile(wb, fileName);
}

function exportTableToPdf() {
    window.jsPDF = window.jspdf.jsPDF;

    // Assuming startDate and endDate are in yyyy-MM-dd format
    var formattedStartDate = fileFormatDate($("#startDate").val());
    var formattedEndDate = fileFormatDate($("#endDate").val());

    // Create the file name based on the start date and end date
    var fileName = `${formattedStartDate}_${formattedEndDate}.pdf`;

    // Create a new jsPDF instance
    var pdf = new jsPDF();

    // Define the columns and data (including the footer row)
    var columns = [];
    $('#tableDonation thead tr th:visible').each(function () {
        columns.push($(this).text());
    });
    var data = [];

    // Iterate through the table rows and add data to the data array
    $('#tableDonation tbody tr:visible').each(function () {
        var rowData = [];
        $(this).find('td:visible').each(function () {
            rowData.push($(this).text());
        });
        data.push(rowData);
    });

    // Calculate the total amount
    var totalAmount = data.reduce(function (sum, row) {
        return sum + parseFloat(row[1].replace(/[^\d.]/g, ''));
    }, 0);

    // Add the footer row with the total amount
    data.push(["Total:", formatAmount(totalAmount)]);

    // Set up the PDF document
    pdf.autoTable({
        head: [columns],
        body: data,
        theme: 'striped',
        margin: { top: 20, left: 10, right: 10, bottom: 10 },
        didDrawPage: function (data) {
            // Add a footer with the date
            var dateFormat = "dd-MM-yyyy";
            var date = new Date();
            var formattedDate = date.toLocaleDateString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
            pdf.text(formattedDate, data.settings.margin.left, pdf.internal.pageSize.height - 10);
        },
    });

    // Save the PDF
    pdf.save(fileName);

}

// Function to format Unix timestamp as "dd-MMM-yyyy"
function formatDate(date) {
    var date = new Date(date);
    var day = date.getDate();
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var monthIndex = date.getMonth();
    var year = date.getFullYear();
    return day + "-" + monthNames[monthIndex] + "-" + year;
}




// Function to format Unix timestamp as "dd-MMM-yyyy"
function formatMonth(date) {
    var date = new Date(date);
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var monthIndex = date.getMonth();
    var year = date.getFullYear();
    return monthNames[monthIndex] + "-" + year;
}

// Function to format Unix timestamp as "dd-MMM-yyyy"
function formatDatetime(date) {
    var timestamp = parseInt(date.substr(6));
    var date = new Date(timestamp);
    var day = date.getDate();
    var hours = date.getHours();
    var minutes = date.getMinutes();

    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var monthIndex = date.getMonth();
    var year = date.getFullYear();
    // Ensure that hours and minutes are two digits each
    var formattedHours = (hours < 10) ? "0" + hours : hours;
    var formattedMinutes = (minutes < 10) ? "0" + minutes : minutes;

    return day + "-" + monthNames[monthIndex] + "-" + year + " " + formattedHours + ":" + formattedMinutes;
}

function createDataTable(arrayTable, data) {
    //var table = $('#tableDonation').DataTable();
    if (table) {
        // If DataTable is already initialized, destroy it before reinitializing
        table.destroy();
    }

    var $table = $("#tableDonation");

    $table.html("");

    // Create the thead element and add it to the table
    var $thead = $("<thead>");
    $table.append($thead);

    // Create the tbody element and add it to the table
    var $tbody = $("<tbody>");
    $table.append($tbody);

    // Create the tfoot element and add it to the table
    var $tfoot = $("<tfoot>");
    $table.append($tfoot);

    // Reference to the table body
    var tableBody = document.querySelector("#tableDonation thead");

    // Reference to the table body
    var tableFooter = document.querySelector("#tableDonation tfoot");

    var row = document.createElement("tr");
    var rowFoot = document.createElement("tr");


    // Populate the table with data
    arrayTable.forEach(function (data) {
        var dataCell = document.createElement("th"); // Change "dateCell" to "dataCell"
        dataCell.textContent = data.DisplayName;
        row.appendChild(dataCell);

        var dataCellFoot = document.createElement("th"); // Change "dateCell" to "dataCell"
        rowFoot.appendChild(dataCellFoot);

        if (data.cssClass) {
            // Split the 'cssClass' property value into an array of CSS classes
            var arrayClass = data.cssClass.split(',');

            // Iterate through each CSS class in the array
            arrayClass.forEach(function (cssClass) {
                // Add each CSS class to the dataCell element
                dataCell.classList.add(cssClass.trim());
                dataCellFoot.classList.add(cssClass.trim());
            });
        }


    });

    tableBody.appendChild(row);
    tableFooter.appendChild(rowFoot);

    var columnConfigurations = [];
    arrayTable.forEach(function (data, index) {
        if (data.Type == "date") {
            // Define dateColumnConfig
            var dateColumnConfig = {
                "targets": index, // Index of the "Slip Date" column (zero-based)
                "render": function (data23, type, row) {
                    // Format the date as "dd-MMM-yyyy"
                    if (type === "sort" || type === "type") {
                        // For sorting and type detection, return a date string in the format "yyyy-mm-dd"
                        //var timestamp = parseInt(data23.substr(6));
                        var date = new Date(data23);
                        return date;
                    } else {
                        // For display, return the original formatted date
                        var dateform = "";
                        dateform = formatDate(data23);
                        if (data.Format && data.Format == "MMM-yyyy")
                            dateform = formatMonth(data23);
                        if (data.IsHyperLink && data.IsHyperLink == true && data.Type == "date") {
                            dateform = '<a href="#">' + dateform + '</a>';
                        }
                        return dateform
                    }
                }
            };
            columnConfigurations.push(dateColumnConfig);
        }
        else if (data.Type == "datetime") {
            // Define dateColumnConfig
            var dateColumnConfig = {
                "targets": index, // Index of the "Slip Date" column (zero-based)
                "render": function (data23, type, row) {
                    // Format the date as "dd-MMM-yyyy"
                    if (type === "sort" || type === "type") {
                        // For sorting and type detection, return a date string in the format "yyyy-mm-dd"
                        //var timestamp = parseInt(data23.substr(6));
                        var date = new Date(data23);
                        return date;
                    } else {
                        // For display, return the original formatted date
                        var dateform = "";
                        dateform = formatDate(data23);
                        if (data.Format && data.Format == "MMM-yyyy")
                            dateform = formatMonth(data23);
                        if (data.IsHyperLink && data.IsHyperLink == true && data.Type == "date") {
                            dateform = '<a href="#">' + dateform + '</a>';
                        }
                        return dateform
                    }
                }
            };
            columnConfigurations.push(dateColumnConfig);
        }
    });

    var orderIndex = 0;
    arrayTable.forEach(function (data, index) {
        if (data.Sorting && data.Sorting == true) {
            orderIndex = index;
        }
    });
    console.log(columnConfigurations[0]);

    table = $('#tableDonation').DataTable({
        "paging": false,
        "order": [[orderIndex, "desc"]], // Sort by column index 2 (Slip Date) in descending order
        "columnDefs": columnConfigurations,
        "footerCallback": function (row, data, start, end, display) {
            var api = this.api();
            arrayTable.forEach(function (data, index) {
                if (data.IsSumRequired && data.IsSumRequired == true) {
                    if (data.Type == "float") {
                        var totalAmount = api
                            .column(index, { search: 'applied' }) // Column index of "Amount"
                            .data()
                            .reduce(function (acc, val) {
                                // Use regular expressions with 'g' flag to replace all occurrences
                                var amount = parseFloat(val.replace(/\$/g, '').replace(/,/g, ''));
                                console.log(amount);
                                return acc + amount;
                            }, 0);
                        var formattedTotalAmount = totalAmount.toLocaleString('en-IN', {
                            style: 'currency',
                            currency: 'INR'
                        }).replace('₹', ''); // Remove the rupee symbol;

                        // Update the "Total" cell in the footer row
                        $(api.column(index).footer()).html(formattedTotalAmount);
                    }
                    else if (data.Type == "int") {
                        var totalAmount = api
                            .column(index, { search: 'applied' }) // Column index of "Amount"
                            .data()
                            .reduce(function (acc, val) {
                                if (typeof val !== 'string') {
                                    val = val.toString(); // Convert to string if it's not already
                                }
                                if (val === undefined) {
                                    val = '0'; // Default value for undefined or non-string values
                                }
                                var amount = parseInt(val.replace('$', '').replace(',', ''), 10);
                                if (!isNaN(amount)) {
                                    return acc + amount;
                                }
                                return acc;
                            }, 0);

                        // Update the "Total" cell in the footer row
                        $(api.column(index).footer()).html(totalAmount);

                    }
                }
                if (data.FooterLabel) {
                    $(api.column(index).footer()).html(data.FooterLabel);
                }
            });
        }
    });

    // Clear existing table data
    table.clear().draw();

    // Loop through the JSON data and add rows to the table
    for (var i = 0; i < data.length; i++) {
        var rowData = data[i];

        var rowDataArray = [
        ];
        arrayTable.forEach(function (data) {
            var dataFieldValue = rowData[data.FieldName];
            if (data.Type == "float") {
                // Format the "Amount" with toLocaleString and right-align it
                dataFieldValue = dataFieldValue.toLocaleString('en-IN', {
                    style: 'currency',
                    currency: 'INR'
                }).replace('₹', ''); // Remove the rupee symbol;
            }
            if (data.IsHyperLink && data.IsHyperLink == true && data.Type != "date") {
                dataFieldValue = '<a href="#" >' + dataFieldValue + '</a>';
            }
            //else if (data.Type == "date") {
            //    dataFieldValue = formatDate(dataFieldValue);
            //}
            rowDataArray.push(dataFieldValue);
        });
        // Add the row to the table
        var row = table.row.add(rowDataArray).draw(false).node();

        // Iterate through each element in the arrayTable array
        arrayTable.forEach(function (data, index) {
            // Check if the 'cssClass' property exists in the current 'data' object
            if (data.cssClass) {
                // Split the 'cssClass' property value into an array of CSS classes
                var arrayclass = data.cssClass.split(',');

                // Iterate through each CSS class in the array
                arrayclass.forEach(function (data2) {
                    // Find the table cell (<td>) at the specified 'index' within the 'row'
                    // and add the current CSS class (data2) to it
                    $(row).find('td:eq(' + index + ')').addClass(data2);
                });
            }
        });

        // Add the CSS class to the EmailAddress column cell

    }

    // Hide the "No records found" message if data is available
    $("#noRecordsMessage").hide();
}

function fetchDataAndUpdateTable(apiUrl, successCallback) {
    // Get the current URL
    var currentUrl = window.location.href;

    // Check if the current URL contains the prefix
    if (currentUrl.includes('ersandeeppruthi')) {
        // Add the prefix to the API endpoint
        apiUrl = '/ersandeeppruthi' + apiUrl;
    }

    // Show the loading overlay
    $("#overlay").show();
    var requestData = {
        startDate: $("#startDate").val(),
        endDate: $("#endDate").val()
    };

    if($('#DoctorFilter'))
    {
        requestData.DoctorId = $('#DoctorFilter').val();
    }

    // Make an AJAX request to the API
    $.ajax({
        url: apiUrl,
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(requestData),
        success: function (data) {
            // Call the provided callback function with the API response data
            successCallback(data);
            // Hide the loading overlay
            $("#overlay").hide();
        },
        error: function (error) {
            // Handle any errors from the API request
            console.error('Error:', error);
            // Show an error message to the user
            alert('An error occurred while fetching data from the API.');
            // Hide the loading overlay
            $("#overlay").hide();
        }
    });
}

function formatDateToYYYYMMDDHHMM(date) {
    var year = date.getFullYear();
    var month = ('0' + (date.getMonth() + 1)).slice(-2); // Adding 1 because months are zero-based
    var day = ('0' + date.getDate()).slice(-2);
    var hours = ('0' + date.getHours()).slice(-2);
    var minutes = ('0' + date.getMinutes()).slice(-2);

    return year + '-' + month + '-' + day + ' ' + hours + ':' + minutes;
}