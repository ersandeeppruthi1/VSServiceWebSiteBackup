﻿$(document).ready(function () {
    PopulateStartDate();
    PopulateEndDate();
    // Fetch data from the API on page load
    fetchData();
});

// Function to fetch data from the API
function fetchData() {
    var apiUrl = '/Rajor/GetListDataMonthly';
    fetchDataAndUpdateTable(apiUrl, createTable);
}

// Function to create the table based on the JSON data
function createTable(data) {
    for (var k = 0; k < data.length; k++) {
        var oldDate = data[k].Date.split('-');
        // Subtract 1 from the month since months are zero-based in JavaScript Date
        var newDateValue = new Date(oldDate[0], oldDate[1] - 1, oldDate[2]);
        data[k].NewDateColumn = newDateValue;
    }
    var arrayTable = [
        { DisplayName: "Date", FieldName: "NewDateColumn", Format: "MMM-yyyy", Type: "date", FooterLabel: "Total:", IsHyperLink: true, cssClass: "date-link" },
        { DisplayName: "Count", FieldName: "TransactionCount", Type: "int", IsSumRequired: true },
        { DisplayName: "Amount", FieldName: "Amount", Type: "float", IsSumRequired: true, cssClass: "text-right" },
    ];

    createDataTable(arrayTable, data);

    // Handle click events on the "Name" links to show row data in a modal
    $("#tableDonation tbody").on("click", ".date-link", function () {
        dateString = $(this).text()
        // Define a mapping of month names to numeric values if not already defined
        var monthMap = {
            "Jan": 1,
            "Feb": 2,
            "Mar": 3,
            "Apr": 4,
            "May": 5,
            "Jun": 6,
            "Jul": 7,
            "Aug": 8,
            "Sep": 9,
            "Oct": 10,
            "Nov": 11,
            "Dec": 12
        };

        // Parse the date string into a JavaScript Date object
        var parts = dateString.split("-");
        var month = parts[0];
        var year = parseInt(parts[1]);
        var date = new Date(year, monthMap[month] - 1, 1); // Subtract 1 from the month to match JavaScript's 0-based month index

        // Calculate the last day of the given month
        var lastDay = new Date(year, date.getMonth() + 1, 0);

        // Format the date as "yyyy-mm-dd"
        var formattedStartDate = year + "-" + (date.getMonth() + 1).toString().padStart(2, '0') + "-01";
        var formattedEndDate = year + "-" + (date.getMonth() + 1).toString().padStart(2, '0') + "-" + lastDay.getDate().toString().padStart(2, '0');

        // Redirect to the specified URL with start date and end date query parameters
        window.location.href = "/Rajor/DailySummary?startDate=" + formattedStartDate + "&endDate=" + formattedEndDate;

    });
}

function PopulateStartDate() {
    // Get the current date
    var currentDate = new Date();

    // Calculate the date 12 months ago
    currentDate.setMonth(currentDate.getMonth() - 12);

    // Extract year and month from the calculated date
    var year = currentDate.getFullYear();
    var month = currentDate.getMonth() + 1; // Adding 1 because getMonth() returns a zero-based month

    // Ensure the month is in two-digit format (e.g., "01" for January)
    if (month < 10)
        month = "0" + month;

    // Construct the formatted start date string in the "YYYY-MM-DD" format
    var formattedStartDate = year + "-" + month + "-01";

    // Set the "startDate" input field value
    $("#startDate").val(formattedStartDate);
}


function PopulateEndDate() {
    var currentDate = new Date();
    // Get the value of "endDate" from the query string
    var endDateFromQueryString = getParameterByName('endDate');

    // If "endDate" is present in the query string, set it as the input field value
    if (endDateFromQueryString !== null) {
        $("#endDate").val(endDateFromQueryString);
    } else {
        // If not found in the query string, set the default "End Date" to the last day of the current month
        var lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

        // Corrected formatting to get the last day of the month
        var formattedEndDate = lastDayOfMonth.getFullYear() + '-' + ('0' + (lastDayOfMonth.getMonth() + 1)).slice(-2) + '-' + ('0' + lastDayOfMonth.getDate()).slice(-2);

        $("#endDate").val(formattedEndDate);
    }
}
